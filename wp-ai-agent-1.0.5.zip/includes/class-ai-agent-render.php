<?php
/**
 * Frontend rendering.
 */

class Ai_Agent_Render {
    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'assets' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_assets' ] );
        add_action( 'wp_footer', [ $this, 'container' ] );
    }

    private function config() {
        $settings = wp_ai_agent_get_settings();

        return [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'ajax'       => admin_url( 'admin-ajax.php' ),
            'assets'     => WP_AI_AGENT_URL . 'assets',
            'enterSend'  => ! empty( $settings['enter_send'] ),
            'sound'      => ! empty( $settings['sound'] ),
            'debug'      => ! empty( $settings['debug'] ),
            'selectors'  => [
                'chatRoot'    => '[data-wpai-chat-root]',
                'messageList' => '[data-wpai-message-list]',
            ],
            'expiry'     => isset( $settings['chat_expiry_minutes'] ) ? (int) $settings['chat_expiry_minutes'] : 20,
            'nonce'      => wp_create_nonce( 'wpai_agent' ),
            'i18n'       => [
                'finished' => __( 'This chat has finished due to inactivity. Click “Start new chat” to continue.', 'wp-ai-agent' ),
                'startNew' => __( 'Start new chat', 'wp-ai-agent' ),
            ],
        ];
    }

    public function assets() {
        wp_enqueue_style( 'wp-ai-agent', WP_AI_AGENT_URL . 'assets/css/chat.css', [], WP_AI_AGENT_VERSION );

        wp_register_script( 'wp-ai-agent-transport', WP_AI_AGENT_URL . 'assets/js/chat-transport.js', [], WP_AI_AGENT_VERSION, true );
        wp_register_script( 'wp-ai-agent-frontend', WP_AI_AGENT_URL . 'assets/js/chat.js', [ 'wp-ai-agent-transport' ], WP_AI_AGENT_VERSION, true );
        wp_localize_script(
            'wp-ai-agent-frontend',
            'WPAI_AGENT',
            [
                'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
                'ajax'       => admin_url( 'admin-ajax.php' ),
                'assets'     => WP_AI_AGENT_URL . 'assets',
                'enterSend'  => ! empty( $settings['enter_send'] ),
                'sound'      => ! empty( $settings['sound'] ),
                'debug'      => ! empty( $settings['debug'] ),
                'selectors'  => [
                    'chatRoot'    => '[data-wpai-chat-root]',
                    'messageList' => '[data-wpai-message-list]',
                ],
                'expiry'     => isset( $settings['chat_expiry_minutes'] ) ? (int) $settings['chat_expiry_minutes'] : 20,
                'nonce'      => wp_create_nonce( 'wpai_agent' ),
                'i18n'       => [
                    'finished' => __( 'This chat has finished due to inactivity. Click “Start new chat” to continue.', 'wp-ai-agent' ),
                    'startNew' => __( 'Start new chat', 'wp-ai-agent' ),
                ],
                'agentProfiles' => wp_ai_agent_get_agent_profiles(),
            ]
        );
        wp_enqueue_script( 'wp-ai-agent-frontend' );
    }

    public function admin_assets( $hook ) {
        if ( 'toplevel_page_wp-ai-agent' !== $hook ) {
            return;
        }

        wp_enqueue_style( 'wp-ai-agent', WP_AI_AGENT_URL . 'assets/css/chat.css', [], WP_AI_AGENT_VERSION );

        wp_register_script( 'wp-ai-agent-transport', WP_AI_AGENT_URL . 'assets/js/chat-transport.js', [], WP_AI_AGENT_VERSION, true );
        wp_register_script( 'wp-ai-agent-admin', WP_AI_AGENT_URL . 'assets/js/chat-admin.js', [ 'wp-ai-agent-transport' ], WP_AI_AGENT_VERSION, true );
        wp_localize_script( 'wp-ai-agent-admin', 'WPAI_CONFIG', $this->config() );
        wp_enqueue_script( 'wp-ai-agent-admin' );
    }

    public function container() {
        echo '<div id="wp-ai-agent-root" data-wpai-chat-root aria-live="polite"></div>';
    }
}
